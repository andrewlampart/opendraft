"""
ABOUTME: Utils package for academic draft AI system
ABOUTME: Provides PDF export, citation management, validation, and document processing utilities
"""

__version__ = "1.0.0"
